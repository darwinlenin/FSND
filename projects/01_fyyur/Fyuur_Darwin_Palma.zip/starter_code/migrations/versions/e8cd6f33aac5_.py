"""empty message

Revision ID: e8cd6f33aac5
Revises: 
Create Date: 2020-03-12 06:43:36.286236

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e8cd6f33aac5'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
